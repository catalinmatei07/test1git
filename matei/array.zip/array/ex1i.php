<?php
$a=array(2,6,1,7,3,6,8,3,3,1);
if(count($a)>0)
{
    echo "taboul poate fi considerat multime";
}
else
{
    echo "tabloul nu poati fi considerat multime";
}
?>