<?php
 $hostname="localhost";
 $username="root";
 $password="";
 $database="centrudeexcelenta";
 $mysqli=mysqli_connect($hostname, $username, $password, $database) or die ("Nu mă pot conecta la baza de date");
?>