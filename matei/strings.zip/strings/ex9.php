<?php
     $letters = 'wholiday.hol@linsila.com, gsobgalyu@lttmobile.com , xmregy28@vidred.gq, 5akshaykhanb@ericreyess.com, jnadermostafa2016@huntarapp.com';
     $split = explode(",",$letters);

     sort($split);

     for($i=0;$i<count($split);$i++){
         for()
     }

?>