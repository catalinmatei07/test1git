<?php
echo " <b>4. Sunt date numerele K și N(N>0). De afișat de N ori numărul K;</b> ","<br>", "<br>";
$k=20;
$n=10;
for($i=0;$i<$n;$i++){
    echo $k. " ";
}
?>