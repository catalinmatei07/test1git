<?php

echo " <b>15. Se consideră numărul natural n. Scrieți un script PHP care afișează ultima cifră a numărului n. De
exemplu, dacă n este 127, programul va afișa 7. </b> ","<br>", "<br>";
$n=127;
echo $n%10;
?>