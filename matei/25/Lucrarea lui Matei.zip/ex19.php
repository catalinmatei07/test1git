<?php

echo " <b>19.  Să se scrie un script PHP care calculează și afișează modulul unui număr. . </b> ","<br>", "<br>";

$a=-4324;
echo abs($a);
?>